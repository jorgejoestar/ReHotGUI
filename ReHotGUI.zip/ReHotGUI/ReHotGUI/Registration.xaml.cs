﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ReHotGUI
{
    /// <summary>
    /// Interaktionslogik für Registration.xaml
    /// </summary>
    public partial class Registration : Page
    {
        Kunde model = new Kunde();
        HotelUser user = new HotelUser();
        public static M120EntitiesNew m120entities = new M120EntitiesNew();
        List<Land> l1 = m120entities.Lands.ToList();
        public Registration()
        {
            InitializeComponent();
            setListInDropDown();
        }

        /*private void Button_Click(object sender, RoutedEventArgs e)
        {
            string anredeChecked;
            string nameFilled = txtName.Text;
            string vornameFilled = txtVorname.Text;

            string strasseFilled;

            short plzFilled = Convert.ToInt16(txtPLZ.Text);
            string ortFilled;
            string emailFilled;


            short birthdateFilled = Convert.ToInt16(birthdate.Text);


            if (rbtn1.IsChecked == true && rbtn2.IsChecked != true)
            {
                anredeChecked = "Herr";
            }
            else
            {
                anredeChecked = "Frau";
            }
            if (anredeChecked != null && txtName != null && txtVorname != null && txtEmail != null && txtPLZ != null && txtOrt != null && txtTelefon != null && birthdate != null)
            {
                string namezusatzFilled = txtNamezusatz.Text;
                string telefonFilled = txtTelefon.Text;
                string mobileFilled = txtMobile.Text;
                long nationalitaetFilled = Convert.ToInt32(txtNationalitaet.Text);
                string passnrFilled = txtPassNr.Text;
            }

        }*/
        public void setListInDropDown()
        {
            foreach(Land land in l1)
            {
                cbLand.Items.Add(land.Name);
            }
        }


        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }

        void Clear()
        {
            txtEmail.Text = txtMobile.Text = txtName.Text = txtNamezusatz.Text  = txtOrt.Text = txtPassNr.Text = txtPLZ.Text = txtStrasseNr.Text = txtTelefon.Text = txtVorname.Text = "";
            btnReg.Content = "Save";
            model.KundeID = 0;

        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            Clear();
        }

        private void btnReg_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string anredeChecked;
                if (rbtn2.IsChecked == true && rbtn1.IsChecked != true)
                {
                    anredeChecked = "Herr";
                }
                else
                {
                    anredeChecked = "Frau";
                }

                using (M120EntitiesNew m120entities = new M120EntitiesNew())
                {
                    model.Anrede = anredeChecked;
                    model.Vorname = txtVorname.Text.Trim();
                    model.Name = txtName.Text.Trim();
                    model.NameZusatz = txtNamezusatz.Text.Trim();
                    model.StrasseNr = txtStrasseNr.Text.Trim();
                    model.Ort = txtOrt.Text.Trim();
                    model.PLZ = Convert.ToInt16(txtPLZ.Text.Trim());
                    model.Email = txtEmail.Text.Trim();
                    model.Web = txtWeb.Text.Trim();
                    model.PassNr = txtPassNr.Text.Trim();
                    model.Telefon = txtTelefon.Text.Trim();
                    model.Mobile = txtMobile.Text.Trim();
                    model.Geburtsdatum = Convert.ToDateTime(birthdate.Text.Trim());
                    model.Nationalitaet = l1.Find(x => x.Name == cbLand.SelectedItem.ToString()).LandID; ;
                    user.HotelUser_Username = txtEmail.Text.Trim();
                    user.HotelUser_Password = txtPW.Text.Trim();
                    m120entities.HotelUsers.Add(user);
                    m120entities.Kundes.Add(model);
                    m120entities.SaveChanges();
                }

                Clear();
                MessageBox.Show("Submitted successfully");

            }
            catch (DbEntityValidationException f)
            {
                foreach (var eve in f.EntityValidationErrors)
                {
                    MessageBox.Show(f.Message);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                        ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }


    }
}

