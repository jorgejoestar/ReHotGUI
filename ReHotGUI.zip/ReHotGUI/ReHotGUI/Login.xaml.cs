﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ReHotGUI
{
    /// <summary>
    /// Interaktionslogik für Login.xaml
    /// </summary>
    public partial class Login : Page
    {
        DataHandler dh1 = new DataHandler();
        private Storyboard imageStoryboard;

        private void storyboard()
        {
            
        }
        /*private void animation()
        {
            DoubleAnimation myDoubleAnimation = new DoubleAnimation();
            myDoubleAnimation.From = 1.0;
            myDoubleAnimation.To = 0.0;
            myDoubleAnimation.Duration = new Duration(TimeSpan.FromSeconds(2));
            myDoubleAnimation.AutoReverse = true;
            myDoubleAnimation.RepeatBehavior = RepeatBehavior.Forever;
            imageStoryboard = new Storyboard();
            imageStoryboard.Children.Add(myDoubleAnimation);
            Storyboard.SetTargetName(myDoubleAnimation, UserPic.Name);
            Storyboard.SetTargetProperty(myDoubleAnimation, new PropertyPath(Image.OpacityProperty));
        }*/
        public Login()
        {
            InitializeComponent();
        }

        private void btnsubmit_Click(object sender, RoutedEventArgs e)
        {
            string filledUSN = txtLoginUN.Text;
            string filledPW = txtLoginPW.Text;

            if(filledPW != "" && filledUSN != "")
            {
                if (dh1.doesUserExist(filledUSN, filledPW) == true)
                {
                    txtLoginPW.BorderBrush = new SolidColorBrush(Colors.Green);
                    txtLoginUN.BorderBrush = new SolidColorBrush(Colors.Green);
                    msgHidden.Visibility = Visibility.Visible;
                    msgHidden.Content = "akzeptiert";
                    msgHidden.Foreground = new SolidColorBrush(Colors.LightGreen);
                }
                else
                {
                    msgHidden.Visibility = Visibility.Visible;
                    msgHidden.Content = "falsch/inexistent";
                    msgHidden.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
            else
            {
                //Felder sind leer
                txtLoginPW.BorderBrush = new SolidColorBrush(Colors.Red);
                txtLoginUN.BorderBrush = new SolidColorBrush(Colors.Red);
            }
        }
    }
}
