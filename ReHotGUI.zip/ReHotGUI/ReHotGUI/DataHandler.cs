﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ReHotGUI
{
    class DataHandler
    {
        M120EntitiesNew u1;
        Administration a1;
        MainWindow m1;
        HotelUser s1 = new HotelUser();
        HotelUser s2 = new HotelUser();
        Kunde k1 = new Kunde();
        

        public bool doesUserExist(string username, string pword)
        {
            try
            {
                using (u1 = new M120EntitiesNew())
                {
                    s1 = u1.HotelUsers.FirstOrDefault(r => r.HotelUser_Username == username);
                    s2 = u1.HotelUsers.FirstOrDefault(p => p.HotelUser_Password == pword);


                    if (s1.HotelUser_Username == username && s2.HotelUser_Password == pword)
                    {
                        a1 = new Administration();
                        m1 = new MainWindow();
                        m1.frame1.Content = a1;
                        MessageBox.Show("yeah");
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("user not found", e.Message);
            }
                return false;
            }
        }
    }

