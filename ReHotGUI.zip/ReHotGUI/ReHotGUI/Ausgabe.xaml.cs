﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ReHotGUI
{
    /// <summary>
    /// Interaktionslogik für Ausgabe.xaml
    /// </summary>
    public partial class Ausgabe : Page
    {
        //private List<Hotel> hotelListe;
        public Ausgabe()
        {
            InitializeComponent();
            datenVorbereiten();

            /*ausgabeListe.ItemsSource = hotelListe;
            ausgabeListe.DisplayMemberPath = "Name";
            ausgabeListe.SelectedValuePath = "ID";*/
        }

        private void datenVorbereiten()
        {
            M120EntitiesNew m120entities = new M120EntitiesNew();
            List<Hotel> h1 = m120entities.Hotels.ToList();
            foreach (Hotel hotel in h1)
            {
                ausgabeListe.Items.Add(hotel.Name);
            }
        }

        /*private void ausgabeListe_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ausgabeListe.SelectedItem != null)
            {
                String name = ((Hotel)ausgabeListe.SelectedItem).Name;
                Int32 id = Convert.ToInt32(ausgabeListe.SelectedValue);
                Int32 index = ausgabeListe.SelectedIndex;
                MessageBox.Show("Ausgewählt Index:" + index + "Ausgewählt ID:" + id + "Ausgewählt Name:" + name);
            }
        }*/

        private void zuruecksetzen_Click(object sender, RoutedEventArgs e)
        {
            ausgabeListe.SelectedIndex = -1;
        }

        private void auswaehlenIndex_Click(object sender, RoutedEventArgs e)
        {
            ausgabeListe.SelectedIndex = 1;
        }

        private void auswaehlenID_Click(object sender, RoutedEventArgs e)
        {
            Int32 fremdschluesselID = 2;
            Int32 index = 0;
            foreach (Hotel eintrag in ausgabeListe.Items)
            {
                if (eintrag.HotelID == fremdschluesselID)
                {
                    break;
                }
                index++;
            }
            ausgabeListe.SelectedIndex = index;
        }
    }
}
