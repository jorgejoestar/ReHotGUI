﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ReHotGUI
{
    /// <summary>
    /// Interaktionslogik für Administration.xaml
    /// </summary>
    public partial class Administration : Page
    {
        private static M120EntitiesNew m120e = new M120EntitiesNew();
        public Administration()
        {
            InitializeComponent();
        }

        /*private void dgKunde_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if(dgKunde.CurrentColumn. !=)
        }*/
        /*
        private void dgKunde_Loaded(object sender, RoutedEventArgs e)
        {
            dgKunde.ItemsSource = m120e.Kundes.ToList();
        }*/
    }
}
